# Product Terms Summary
Document ID: POL-PRD-010 | Version 4.0 | Effective 01-Apr-2026 | Owner: Product

## Classic Card
Interest-free period up to 48 days. Revolve rate 3.4% per month. Minimum due 5%.

## Signature Card
Interest-free period up to 50 days. Revolve rate 3.1% per month. Minimum due 5%.
Includes lounge access, 4 domestic visits per quarter.

## Personal Loan
Tenure 12 to 60 months. Rate from 10.75% reducing, subject to assessment.
Foreclosure permitted after 6 EMIs, charge 4% of outstanding principal.
