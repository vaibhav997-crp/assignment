# Periodic KYC Refresh
Document ID: POL-KYC-008 | Version 3.3 | Effective 01-Feb-2026 | Owner: Compliance

Re-KYC is due every 2 years for high-risk customers, 8 years for medium-risk and
10 years for low-risk. Where re-KYC is overdue by more than 90 days:
- Outbound credit offers are suppressed.
- Existing limits are unaffected but may not be increased.
- The account is not frozen solely on this basis.
