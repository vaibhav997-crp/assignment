# Credit Limit Increase Policy
Document ID: POL-CRD-001 | Version 4.2 | Effective 01-Apr-2026 | Owner: Credit Policy

## 1. Eligibility
A cardholder may be considered for a limit increase where all of the following hold:
- The card has been open for at least 6 statement cycles.
- No payment has been more than 30 days past due in the last 12 months.
- Current utilisation over the last 3 cycles averages at least 40%.
- The customer's internal behavioural score is 620 or above.

## 2. Maximum increase
The revised limit must not exceed the lower of:
- 2.0x the existing limit, and
- 4.0x the customer's assessed monthly net income.

## 3. Mandatory declines
A request must be declined, without discretion, where any of the following apply:
- The debt-burden ratio after the increase would exceed 55%.
- The customer is flagged under POL-CON-004 (vulnerable customer).
- An unresolved dispute exists on the account.
- The customer has had a limit increase approved in the preceding 6 months.

## 4. Adverse action
Where a request is declined the customer must be given a reason in plain language
within 7 calendar days. Internal score values are never disclosed. See POL-GOV-009.
