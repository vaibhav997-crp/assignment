# Adverse Action Reasons
Document ID: POL-GOV-009 | Version 2.0 | Effective 01-Feb-2026 | Owner: Model Risk

Where an automated or model-assisted decision results in a decline, a reduced offer
or a higher price, the customer is owed a reason in plain language.

The reason given must:
- Describe the customer-observable factor, not the internal score or model feature.
- Be one of the approved reason codes in Appendix A.
- Never reference a protected characteristic, whether or not it was used.

Approved reason codes: AA01 recent missed payments; AA02 existing obligations
relative to income; AA03 limited credit history with us; AA04 an open dispute on
the account; AA05 a recent change to your limit; AA06 information we hold needs
to be refreshed.
