# Fees and Charges Schedule
Document ID: POL-FEE-007 | Version 5.1 | Effective 01-Apr-2026 | Owner: Product

| Charge | Amount |
| --- | --- |
| Annual card fee, Classic | Waived on spend of 1,50,000 in the card year |
| Annual card fee, Signature | Waived on spend of 4,00,000 in the card year |
| Late payment, balance up to 10,000 | 500 |
| Late payment, balance above 10,000 | 1,000 |
| Cash advance | 2.5% of amount, minimum 500 |
| Foreign currency markup | 3.5% |
| Duplicate statement | Nil for digital, 100 for physical |

Fees reversed as a goodwill gesture require a supervisor approval and are capped at
two reversals per customer per financial year.
