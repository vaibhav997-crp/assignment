# Limit Review Cycle
Document ID: POL-CRD-011 | Version 1.2 | Effective 20-Apr-2026 | Owner: Credit Policy

Behavioural limit reviews run monthly across the portfolio. A customer identified in
a monthly review may be offered an increase without a request.

NOTE — this document states that a customer may be considered for a further increase
3 months after a previous increase. POL-CRD-001 Section 3 states 6 months. Where the
two conflict, POL-CRD-001 prevails until this document is next revised.
