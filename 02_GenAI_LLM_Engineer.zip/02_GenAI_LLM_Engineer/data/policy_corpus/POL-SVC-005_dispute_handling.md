# Transaction Dispute Handling
Document ID: POL-SVC-005 | Version 2.6 | Effective 10-Mar-2026 | Owner: Service Operations

A dispute may be raised within 60 days of the statement on which the transaction appears.
Provisional credit is applied within 5 working days for card-present fraud claims and
within 10 working days for all other categories.

While a dispute is open on an account:
- No credit limit increase may be processed.
- The disputed amount is excluded from utilisation calculations.
- The customer is contacted at least once every 15 days with a status update.
