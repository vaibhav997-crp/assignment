# Income Assessment Standard
Document ID: POL-CRD-002 | Version 2.1 | Effective 15-Jan-2026 | Owner: Credit Policy

Assessed monthly net income is established, in order of preference, from:
1. Salary credits observed in a bank account held with us, averaged over 6 months.
2. Consented Account Aggregator data covering at least 3 months.
3. Documentary evidence — payslips or ITR — not older than 12 months.

Where none is available the customer is treated as thin-file and Section 5 of
POL-CRD-003 applies. Estimated income derived from spend patterns may support a
review but must never be the sole basis for an increase.
