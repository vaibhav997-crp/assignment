# Thin-File and New-to-Credit Customers
Document ID: POL-CRD-003 | Version 1.4 | Effective 15-Jan-2026 | Owner: Credit Policy

## 5. Treatment
A thin-file customer is one with fewer than 6 months of internal repayment history
and no bureau record, or a bureau record with fewer than 2 trade lines.

Thin-file customers remain eligible for a limit increase but the maximum increase
is capped at 1.25x the existing limit regardless of Section 2 of POL-CRD-001.
Requests must be referred to a credit officer and may not be auto-decisioned.
