# Vulnerable Customer Policy
Document ID: POL-CON-004 | Version 3.0 | Effective 01-Feb-2026 | Owner: Conduct Risk

A customer may be flagged as vulnerable following a service interaction, a declared
circumstance, or a conduct review. The flag is set by the Conduct team only.

Where a customer is flagged:
- All outbound sales and cross-sell activity is suppressed immediately.
- Credit limit increases are declined regardless of score or affordability.
- Any recommendation surfaced to a relationship manager must be removed from the
  list, not merely ranked lower.
- The flag is reviewed every 90 days and may be lifted only by the Conduct team.
